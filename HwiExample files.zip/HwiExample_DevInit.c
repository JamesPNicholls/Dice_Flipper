// Filename:            HwiExample_DeviceInit.c
//
// Description:	        Initialization code for Hwi Example
//
// Version:             1.0
//
// Target:              TMS320F28027
//
// Author:              David Romalo
//
// Date:                6Nov2022

#include <Headers/F2802x_Device.h>

extern void DelayUs(Uint16);

void DeviceInit(void)
{
EALLOW; //allow access to protected registers
//initialize GPIO:
    //configure D2 (right-most blue LED)
    GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 0; //set pin as gpio
    GpioCtrlRegs.GPADIR.bit.GPIO0 = 1; //set gpio as output
    GpioDataRegs.GPASET.bit.GPIO0 = 1; //initialize output value to "1"

    //configure D4 (second-from-right blue LED)
    GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 0; //set pin as gpio
    GpioCtrlRegs.GPADIR.bit.GPIO1 = 1; //set gpio as output
    GpioDataRegs.GPASET.bit.GPIO1 = 1; //initialize output value to "1"

    //configure D3 (second-from-left blue LED)
    GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 0; //set pin as gpio
    GpioCtrlRegs.GPADIR.bit.GPIO2 = 1; //set gpio as output
    GpioDataRegs.GPASET.bit.GPIO2 = 1; //initialize output value to "1"

    //configure D5 (left-most blue LED)
    GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 0; //set pin as gpio
    GpioCtrlRegs.GPADIR.bit.GPIO3 = 1; //set gpio as output
    GpioDataRegs.GPASET.bit.GPIO3 = 1; //initialize output value to "1"

// LOW SPEED CLOCKS prescale register settings
   SysCtrlRegs.LOSPCP.all = 0x0002; // Sysclk / 4 (15 MHz)
   SysCtrlRegs.XCLK.bit.XCLKOUTDIV=2;
      	
// PERIPHERAL CLOCK ENABLES 
//---------------------------------------------------
// If you are not using a peripheral you may want to switch
// the clock off to save power, i.e., set to =0 
// 
// Note: not all peripherals are available on all 280x derivates.
// Refer to the datasheet for your particular device. 

   SysCtrlRegs.PCLKCR0.bit.ADCENCLK = 1;    // ADC
   //------------------------------------------------
   SysCtrlRegs.PCLKCR3.bit.COMP1ENCLK = 0;	// COMP1
   SysCtrlRegs.PCLKCR3.bit.COMP2ENCLK = 0;	// COMP2
   //------------------------------------------------
   SysCtrlRegs.PCLKCR0.bit.I2CAENCLK = 0;   // I2C
   //------------------------------------------------
   SysCtrlRegs.PCLKCR0.bit.SPIAENCLK = 0;	// SPI-A
   //------------------------------------------------
   SysCtrlRegs.PCLKCR0.bit.SCIAENCLK = 0;  	// SCI-A
   //------------------------------------------------
   SysCtrlRegs.PCLKCR1.bit.ECAP1ENCLK = 0;	//eCAP1
   //------------------------------------------------
   SysCtrlRegs.PCLKCR1.bit.EPWM1ENCLK = 0;  // ePWM1
   SysCtrlRegs.PCLKCR1.bit.EPWM2ENCLK = 0;  // ePWM2
   SysCtrlRegs.PCLKCR1.bit.EPWM3ENCLK = 0;  // ePWM3
   SysCtrlRegs.PCLKCR1.bit.EPWM4ENCLK = 0;  // ePWM4
   //------------------------------------------------
   SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;   // Enable TBCLK
   //------------------------------------------------
                  
// INITIALIZE A-D
//---------------------------------------------------------------
//input channel = junction temperature sensor, SOC0, software triggering

    //simultaneously power up ADC's analog circuitry, bandgap, and reference buffer:
    AdcRegs.ADCCTL1.all = 0x00e0;
    //bit 7     ADCPWDN (ADC power down): 0=powered down, 1=powered up
    //bit 6     ADCBGPWD (ADC bandgap power down): 0=powered down, 1=powered up
    //bit 5     ADCREFPWD (ADC reference power down): 0=powered down, 1=powered up

    //generate INT pulse on end of conversion:
    AdcRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    //enable ADC:
    AdcRegs.ADCCTL1.bit.ADCENABLE = 1;

    //wait 1 ms after power-up before using the ADC:
    DelayUs(1000);

    //configure to sample on-chip temperature sensor:
    AdcRegs.ADCCTL1.bit.TEMPCONV = 1; //connect A5 to temp sensor
    AdcRegs.ADCSOC0CTL.bit.TRIGSEL = 2; //trigger source = CPU Timer 1
    AdcRegs.ADCSOC0CTL.bit.CHSEL = 5; //set SOC0 to sample A5
    AdcRegs.ADCSOC0CTL.bit.ACQPS = 0x6; //set SOC0 window to 7 ADCCLKs
    AdcRegs.INTSEL1N2.bit.INT1SEL = 0; //connect interrupt ADCINT1 to EOC0
    AdcRegs.INTSEL1N2.bit.INT1E = 1; //enable interrupt ADCINT1

EDIS; //disallow access to protected registers
} // end DeviceInit()

